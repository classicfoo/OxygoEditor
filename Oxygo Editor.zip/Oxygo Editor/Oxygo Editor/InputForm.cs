﻿/*
 * Created by SharpDevelop.
 * User: Michael
 * Date: 03-Dec-17
 * Time: 2:48 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Oxygo_Editor
{
	/// <summary>
	/// Description of AddTagForm.
	/// </summary>
	public partial class InputForm : Form
	{
		public InputForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void Ok_buttonClick(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
