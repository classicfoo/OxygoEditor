﻿/*
 * Created by SharpDevelop.
 * User: Michael
 * Date: 03-Dec-17
 * Time: 1:25 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace Oxygo_Editor
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		
		private string _fileName;
		public string FileName {
			get
			{
				return _fileName;
			}
			set
			{
				_fileName = value;
				this.Text = Application.ProductName + " - " + Path.GetFileName(_fileName);
			}
		}
		
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			richTextBox1.AllowDrop = true;
			richTextBox1.DragEnter += richTextBox1_DragEnter;
			richTextBox1.DragDrop += richTextBox1_DragDrop;
			Populate_ListBox();
			
			listBox1.AllowDrop = true;
			listBox1.DragOver += listBox1_DragOver;
			listBox1.DragDrop += listBox1_DragDrop;
			listBox1.MouseDown += ListBox1MouseDown;
			listBox1.KeyDown += ListBox1KeyDown;
			
			this.KeyDown += MainFormKeyDown;
			
			_fileName = "";
		}
		
		void MainFormKeyDown(object sender, KeyEventArgs e)
		{
			if(e.Modifiers == Keys.Control && e.KeyCode == Keys.S)
			{
				SaveAsFile();
			}
			
			if(e.KeyData == Keys.F5)
			{
				if(FileName != "")
				{
					System.Diagnostics.Process.Start(FileName);
				}
			}
		}
		
		void ListBox1MouseDown(object sender, MouseEventArgs e)
		{
		    if(listBox1.Items.Count==0) return;
		    
		    int index = listBox1.IndexFromPoint(e.X,e.Y);
		    
		    if(index != -1) {
			    string s = listBox1.Items[index].ToString(); 
			    DragDropEffects dde1=DoDragDrop(s, DragDropEffects.All);
			 
			    if(dde1 == DragDropEffects.All )
			    { 
			        listBox1.Items.RemoveAt(listBox1.IndexFromPoint(e.X,e.Y)); 
			    }
		    }
		    
            if (this.listBox1.SelectedItem == null) return;
    		this.listBox1.DoDragDrop(this.listBox1.SelectedItem, DragDropEffects.Move);
		    
		}
		
		private void listBox1_DragOver(object sender, DragEventArgs e)
	    {
	        e.Effect = DragDropEffects.Move;
	    }
		
		private void listBox1_DragDrop(object sender, DragEventArgs e)
	    {
	        Point point = listBox1.PointToClient(new Point(e.X, e.Y));
	        int index = this.listBox1.IndexFromPoint(point);
	        if (index < 0) index = this.listBox1.Items.Count - 1;
	        object data = listBox1.SelectedItem;
	        this.listBox1.Items.Remove(data);
	        this.listBox1.Items.Insert(index, data);
	        WriteToFile();
	    }
		
		private void richTextBox1_DragEnter(object sender, DragEventArgs e)
		{
		   // If the data is text, copy the data to the RichTextBox control.
		   if(e.Data.GetDataPresent("Text"))
		      e.Effect = DragDropEffects.Copy;
		}
		
		private void richTextBox1_DragDrop(object sender, DragEventArgs e) 
		{
		   // Paste the text into the RichTextBox where at selection location.
		   richTextBox1.SelectedText =  e.Data.GetData("System.String", true).ToString();
		}
			
		
		public void Populate_ListBox()
		{
			string[] lines = File.ReadAllLines(@"tags.txt");
			foreach (string line in lines)
			{
				listBox1.Items.Add(line);
			}

		}
		

		void ListBox1KeyDown(object sender, KeyEventArgs e)
		{
			if(e.KeyData == Keys.Delete)
			{
				DeleteSnippet();
			}
		}
		
		void DeleteSnippet()
		{
				if(listBox1.SelectedIndex != -1)
				{
					listBox1.Items.RemoveAt(listBox1.SelectedIndex);
					WriteToFile();
				}
		}
		
		void WriteToFile()
		{
			using(var writer = new StreamWriter(@"tags.txt")){
				writer.Write("");
			}
			foreach(var text in listBox1.Items)
			{

				using(var writer = new StreamWriter(@"tags.txt", true)){
					writer.WriteLine(text);
				}
			}
		}
		
		void SaveAsFile()
		{
			if(FileName == "")
			{
				SaveFileDialog saveFileDialog1 = new SaveFileDialog();  
			   saveFileDialog1.Filter = "HTML file|*.html|CSS file|*.css|Javascript|*.js";  
			   saveFileDialog1.Title = "Save a File";  
			   saveFileDialog1.ShowDialog();  
			
			   // If the file name is not an empty string open it for saving.  
			   if(saveFileDialog1.FileName != "")  
			   {  
	      			using (var writer = new StreamWriter(saveFileDialog1.FileName)) {
	      				writer.WriteLine(richTextBox1.Text);
		         	}
			   } 
			   FileName = saveFileDialog1.FileName;
			}
			else {
				using (var writer = new StreamWriter(FileName)) {
	      			writer.WriteLine(richTextBox1.Text);
		        }
			}
			   
			}
		
		void SaveAsToolStripMenuItemClick(object sender, EventArgs e)
		{
			SaveAsFile();

		}
		void OpenToolStripMenuItemClick(object sender, EventArgs e)
		{
			DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
            if (result == DialogResult.OK) // Test result.
            {
                string file = openFileDialog1.FileName;
                try
                {
                    string text = File.ReadAllText(file);
                    richTextBox1.Text = text;
                }
                catch (IOException)
                {
                }
            }
            
		   	FileName = openFileDialog1.FileName;
		}
		void SnippetToolStripMenuItemClick(object sender, EventArgs e)
		{
	
		}
		void NewToolStripMenuItem1Click(object sender, EventArgs e)
		{
			var atf = new InputForm();
			atf.Text = "New Snippet";
			if(atf.ShowDialog(this) == DialogResult.OK)
			{
				var text = atf.textBox1.Text;
				listBox1.Items.Add(text);
				StreamWriter writer = new StreamWriter(@"tags.txt", true);
				writer.WriteLine(text);
				writer.Close();
			}
		}
		
		void DeleteToolStripMenuItemClick(object sender, EventArgs e)
		{
			DeleteSnippet();
		}

		void filterToolStripMenuItemClick(object sender, EventArgs e)
		{
			
		}
		void NewToolStripMenuItemClick(object sender, EventArgs e)
		{
			var split = this.Text.Split('-');
			this.Text = split[0];
			richTextBox1.Text = "";
			_fileName = "";
		}
		void EditToolStripMenuItemClick(object sender, EventArgs e)
		{
			var input = new InputForm();
			input.Text = "Edit Snippet";
			
			var selectedSnippetIndex = listBox1.SelectedIndex;
			input.textBox1.Text = listBox1.Items[selectedSnippetIndex].ToString();

			if(input.ShowDialog(this) == DialogResult.OK)
			{
				listBox1.Items[selectedSnippetIndex] = input.textBox1.Text;
				StreamWriter writer = new StreamWriter(@"tags.txt", true);
				writer.WriteLine(input.textBox1.Text);
				writer.Close();
			}
			input.Dispose();
		}

	}
}
