﻿/*
 * Created by SharpDevelop.
 * User: Michael
 * Date: 03-Dec-17
 * Time: 2:48 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Oxygo_Editor
{
	partial class InputForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		public System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Button cancel_button;
		private System.Windows.Forms.Button ok_button;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.cancel_button = new System.Windows.Forms.Button();
			this.ok_button = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(12, 12);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(277, 20);
			this.textBox1.TabIndex = 0;
			// 
			// cancel_button
			// 
			this.cancel_button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.cancel_button.Location = new System.Drawing.Point(157, 38);
			this.cancel_button.Name = "cancel_button";
			this.cancel_button.Size = new System.Drawing.Size(75, 23);
			this.cancel_button.TabIndex = 2;
			this.cancel_button.Text = "Cancel";
			this.cancel_button.UseVisualStyleBackColor = true;
			// 
			// ok_button
			// 
			this.ok_button.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.ok_button.Location = new System.Drawing.Point(76, 38);
			this.ok_button.Name = "ok_button";
			this.ok_button.Size = new System.Drawing.Size(75, 23);
			this.ok_button.TabIndex = 1;
			this.ok_button.Text = "OK";
			this.ok_button.UseVisualStyleBackColor = true;
			this.ok_button.Click += new System.EventHandler(this.Ok_buttonClick);
			// 
			// InputForm
			// 
			this.AcceptButton = this.ok_button;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(301, 69);
			this.Controls.Add(this.ok_button);
			this.Controls.Add(this.cancel_button);
			this.Controls.Add(this.textBox1);
			this.Name = "InputForm";
			this.Text = "InputForm";
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
